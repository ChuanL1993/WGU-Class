Author: Chuan Liu
Contact: cliu11@wgu.edu
Application Version: v1.01
Date: 04/17/2021
IDE: Apache NetBeans IDE 12.3
JDK version: Java™ SE Development Kit 11.0.10 (JDK 11.0.10)
MySQL Connector driver:mysql-connector-java-8.0.22

Addition report include: 1)Total number of appointments
		        2)Earliest and latest appointment
		        3)Number of each type of appointments
		        4)Number of appointment created by each user.

Instruction on program:
start the program, login with correct username and password(username and password provided below)
Now you can access all the appointments and users information from database.
For appointment part:
To add new appointment: click new button and fill in the information to create a new appointment.
To update appointment: click modify button and and fill in the information to update the appointment.
To delete appointment: click delete button to do the deletion.
For customer part:
To add new customer: click new button under customer table and add it with the information.
To update customer : click modify button under customer table and update it with information.
To delete customer: click delete button under customer table and delete it(Note: You may not able to delete a customer
if the customer has appointment assigned)
Report:
Click on each radio button to see the report of each type.
Click exit to close the program.

Hello there,
The path of javadoc is \WGUC195\dist\javadoc\index.html

just in case if you have trouble find it. I put a copy at root folder as well.

The login_ log is in WGUC195 folder
Login_log show login detail.

I also put driver in the root folder.

Lambda expression I used is in MainMenuController.java at line566-line569.
Second Lambda expression is in NewAppointmentController.java at line 108-line129.

There are 3 username and password to get in software
username         password

test                    test
admin                admin
1                         1


Thank you!

 